# hl7.fhir.no.mal#0.1.0: Mal

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Mal](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
